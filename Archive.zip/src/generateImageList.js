// src/storeImageInfo.js
const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');

const imageFolder = '../public/images'; // Path to your image folder
const outputFileName = 'imageInfo.json'; // Output file path

const storeImageInfo = () => {
  const imageData = {
    imageFolders: [],
    latestImageTimestamp: new Date().toISOString(),
  };

  const storeImageData = () => {
    fs.writeFileSync(outputFileName, JSON.stringify(imageData, null, 2), 'utf-8');
    console.log('Image information stored:', outputFileName);
  };

  const updateImageList = () => {
    fs.readdir(imageFolder, (err, folders) => {
      if (err) {
        console.error('Error reading image folder:', err);
        return;
      }

      imageData.imageFolders = [];

      folders.forEach((folder) => {
        const folderPath = path.join(imageFolder, folder);
        if (fs.statSync(folderPath).isDirectory()) {
          const imageFiles = fs.readdirSync(folderPath)
            .filter((file) => /\.(png|jpe?g|svg)$/i.test(file)); // Filter by image file extensions

          if (imageFiles.length > 0) {
            // Construct an array of image filenames with a leading slash
            const images = imageFiles.map((file) => '/' + file);
            
            imageData.imageFolders.push({
              folderName: folder,
              images: images,
            });
          }
        }
      });

      imageData.latestImageTimestamp = new Date().toISOString();
      storeImageData();
    });
  };

  // Initial setup
  updateImageList();

  // Watch the image folder for changes
  const watcher = chokidar.watch(imageFolder, { ignoreInitial: true });
  watcher
    .on('add', () => {
      console.log('New image added.');
      updateImageList();
    })
    .on('unlink', () => {
      console.log('Image removed.');
      updateImageList();
    });
};

storeImageInfo(); // Start storing image information
