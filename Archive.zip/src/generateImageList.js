// src/generateImageList.js
const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');

const imageFolder = '../public/images'; // Path to your image folder
const outputFileName = 'imageList.json'; // Output file path

const generateImageList = () => {
  fs.readdir(imageFolder, (err, files) => {
    if (err) {
      console.error('Error reading image folder:', err);
      return;
    }

    const imageFiles = files
      .filter((file) => /\.(png|jpe?g|svg)$/i.test(file))
      .map((file) => path.join('images', file)); // Relative paths

    const latestImageTimestamp = new Date().toISOString();
    const imageData = {
      images: imageFiles,
      latestImageTimestamp,
    };

    fs.writeFileSync(outputFileName, JSON.stringify(imageData, null, 2), 'utf-8');
    console.log('Image list generated:', outputFileName);
  });
};

// Watch the images folder for changes
const watcher = chokidar.watch(imageFolder, { ignoreInitial: true });
watcher
  .on('add', () => {
    console.log('New image added. Regenerating image list...');
    generateImageList();
  })
  .on('unlink', () => {
    console.log('Image removed. Regenerating image list...');
    generateImageList();
  });

generateImageList(); // Generate the initial image list
