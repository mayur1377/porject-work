// src/components/ImageGallery.js
import React, { useState, useEffect } from 'react';
import imageList from '../imageList.json';

function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  const options = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  };
  return date.toLocaleString(undefined, options);
}

function ImageGallery() {
  const [latestImageTimestamp, setLatestImageTimestamp] = useState('');

  useEffect(() => {
    // Fetch the latest image timestamp from imageList.json
    setLatestImageTimestamp(formatTimestamp(imageList.latestImageTimestamp));
  }, []);

  // Define the desired image size (width and height)
  const imageSize = {
    width: '200px', // Adjust this to your desired width
    height: '200px', // Adjust this to your desired height
  };

  return (
    <div className="image-gallery">
      <h2>Last time data was updated :</h2>
      <p>{latestImageTimestamp}</p>

      <h2>Images:</h2>
      {imageList.images.length === 0 ? (
        <p>No images</p>
      ) : (
        imageList.images.map((image, index) => (
          <div key={index}>
            <h5>{image}</h5>
            <img
              src={process.env.PUBLIC_URL + '/' + image}
              alt={`Image ${index}`}
              style={imageSize} // Apply the fixed size here
            />
          </div>
        ))
      )}
    </div>
  );
}

export default ImageGallery;
