// src/components/ImageGallery.js
import React, { useState, useEffect } from 'react';
import imageData from '../imageInfo.json'; // Import the JSON data

function ImageGallery() {
  const [imageFolders, setImageFolders] = useState([]);

  useEffect(() => {
    if (imageData && imageData.imageFolders) {
      setImageFolders(imageData.imageFolders);
    }
  }, []);

  // Helper function to get the folder path of each image
  function getFolderPath(folderName) {
    return `/images/${folderName}`; // Relative path to public/images
  }

  // Define the desired image size (width and height)
  const imageSize = {
    width: '600px', // Adjust this to your desired width
    height: '600px', // Adjust this to your desired height
  };

  return (
    <div>
      <h1>Images in Subfolders</h1>
      <div className="image-container">
        {imageFolders.length > 0 ? (
          imageFolders.map((folder, folderIndex) => (
            <div key={folderIndex}>
              <h2>{folder.folderName}</h2>
              <div className="images">
                {folder.images.map((imagePath, index) => (
                  <div key={index} className="image-item">
                    <img
                      src={`${process.env.PUBLIC_URL}${getFolderPath(folder.folderName)}/${imagePath}`}
                      alt={`Image ${index}`}
                      style={imageSize} // Apply the fixed size here
                    />
                    <p>{imagePath.slice(1)}</p> {/* Display image name */}
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <p>No image folders found.</p>
        )}
      </div>
    </div>
  );
}

export default ImageGallery;
