// src/components/DisplayTime.js
import React, { useState, useEffect } from 'react';

function DisplayTime() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Cleanup the interval when the component unmounts
    return () => clearInterval(intervalId);
  }, []);

  const formattedTime = currentTime.toLocaleTimeString();

  const style = {
    position: 'absolute',
    top: '10px', // Adjust the top position as needed
    right: '10px', // Adjust the right position as needed
  };

  return (
    <div className="display-time" style={style}>
      <p>{formattedTime}</p>
    </div>
  );
}

export default DisplayTime;
