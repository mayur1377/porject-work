// src/App.js
import React from 'react';
import './App.css';
import ImageGallery from './components/ImageGallery';
import DisplayTime from './components/Displaytime';

function App() {
  return (
    <div className="App">
      <DisplayTime />
      <h1>DATA TO BE SHOWN HERE</h1>
      <ImageGallery />
    </div>
  );
}

export default App;
